package com.jarvis.ai

/**
 * Plug-in point for an external AI API (writing help, translation, free conversation).
 * Implement this with your provider of choice, add the INTERNET permission to the manifest,
 * and return it from JarvisViewModel. Until then NotConfiguredBrain is used.
 */
interface AssistantBrain {
    val isConfigured: Boolean
    suspend fun respond(prompt: String, languageTag: String?): Result<String>
}

class NotConfiguredBrain : AssistantBrain {
    override val isConfigured = false
    override suspend fun respond(prompt: String, languageTag: String?): Result<String> =
        Result.failure(IllegalStateException("No AI service configured"))
}
