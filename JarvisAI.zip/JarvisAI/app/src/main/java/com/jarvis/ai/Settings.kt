package com.jarvis.ai

import android.content.Context
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import java.util.Locale

enum class AppLanguage(val tag: String?, val label: String) {
    DEVICE(null, "Device default"),
    ENGLISH("en-US", "English"),
    HAUSA("ha-NG", "Hausa");

    val isHausa get() = this == HAUSA
    val locale: Locale get() = tag?.let { Locale.forLanguageTag(it) } ?: Locale.getDefault()
}

data class Settings(
    val language: AppLanguage = AppLanguage.ENGLISH,
    val voiceOutput: Boolean = true,
    val speechRate: Float = 1f,
)

class SettingsRepository(context: Context) {
    private val prefs = context.getSharedPreferences("jarvis_settings", Context.MODE_PRIVATE)
    private val _settings = MutableStateFlow(load())
    val settings: StateFlow<Settings> = _settings.asStateFlow()

    private fun load() = Settings(
        language = runCatching { AppLanguage.valueOf(prefs.getString("lang", "ENGLISH")!!) }
            .getOrDefault(AppLanguage.ENGLISH),
        voiceOutput = prefs.getBoolean("voice", true),
        speechRate = prefs.getFloat("rate", 1f),
    )

    fun update(transform: (Settings) -> Settings) {
        val s = transform(_settings.value)
        _settings.value = s
        prefs.edit().putString("lang", s.language.name).putBoolean("voice", s.voiceOutput)
            .putFloat("rate", s.speechRate).apply()
    }
}
