package com.jarvis.ai.ui

import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

val JarvisBg = Color(0xFF02040A)
val JarvisBgTop = Color(0xFF071A33)
val JarvisBlue = Color(0xFF1E90FF)
val JarvisCyan = Color(0xFF00E5FF)
val JarvisText = Color(0xFFE6F3FF)
val JarvisMuted = Color(0xFF7FA3C7)

@Composable
fun JarvisTheme(content: @Composable () -> Unit) {
    MaterialTheme(
        colorScheme = darkColorScheme(
            primary = JarvisCyan, secondary = JarvisBlue, background = JarvisBg,
            surface = Color(0xFF0A1424), onPrimary = JarvisBg, onSurface = JarvisText,
            onBackground = JarvisText,
        ),
        content = content,
    )
}
