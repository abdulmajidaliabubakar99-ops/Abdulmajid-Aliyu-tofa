package com.jarvis.ai.ui

import android.Manifest
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.provider.Settings as AndroidSettings
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.rounded.ArrowBack
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.text.font.FontWeight
import androidx.core.content.ContextCompat
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.LifecycleEventObserver
import androidx.lifecycle.compose.LocalLifecycleOwner
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.jarvis.ai.AppLanguage
import com.jarvis.ai.JarvisViewModel

@Composable
fun SettingsScreen(vm: JarvisViewModel, onBack: () -> Unit) {
    val s by vm.settings.collectAsStateWithLifecycle()
    val context = LocalContext.current
    val owner = LocalLifecycleOwner.current
    var micGranted by remember { mutableStateOf(hasMic(context)) }
    DisposableEffect(owner) {
        val obs = LifecycleEventObserver { _, e -> if (e == Lifecycle.Event.ON_RESUME) micGranted = hasMic(context) }
        owner.lifecycle.addObserver(obs)
        onDispose { owner.lifecycle.removeObserver(obs) }
    }

    Column(
        Modifier.fillMaxSize().background(Brush.verticalGradient(listOf(JarvisBgTop, JarvisBg)))
            .statusBarsPadding().navigationBarsPadding().verticalScroll(rememberScrollState()).padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(8.dp),
    ) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            IconButton(onClick = onBack) { Icon(Icons.AutoMirrored.Rounded.ArrowBack, "Back", tint = JarvisText) }
            Text("Settings", color = JarvisCyan, fontSize = 22.sp, fontWeight = FontWeight.Bold)
        }

        Section("Language")
        AppLanguage.entries.forEach { lang ->
            Row(Modifier.fillMaxWidth().clickable { vm.setLanguage(lang) }, verticalAlignment = Alignment.CenterVertically) {
                RadioButton(selected = s.language == lang, onClick = { vm.setLanguage(lang) })
                Text(lang.label, color = JarvisText)
            }
        }
        Note("Used for speech recognition, spoken replies and reply text. Commands in English or Hausa are understood either way. Hausa recognition and voice depend on your device's speech services — if unsupported, JARVIS will tell you.")

        Section("Voice output")
        Row(verticalAlignment = Alignment.CenterVertically) {
            Text("Speak replies aloud", color = JarvisText, modifier = Modifier.weight(1f))
            Switch(checked = s.voiceOutput, onCheckedChange = vm::setVoiceOutput)
        }
        Text("Speech speed: ${"%.1f".format(s.speechRate)}x", color = JarvisText)
        Slider(value = s.speechRate, onValueChange = vm::setSpeechRate, valueRange = 0.5f..1.5f, enabled = s.voiceOutput)
        OutlinedButton(onClick = { openTtsSettings(context) }) { Text("Install / change voices") }

        Section("Microphone")
        Text(if (micGranted) "Permission granted. JARVIS only listens after you tap the mic." else "Permission not granted. Typing still works; tap the mic to be asked.", color = JarvisText)
        OutlinedButton(onClick = {
            context.startActivity(Intent(AndroidSettings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.fromParts("package", context.packageName, null)))
        }) { Text("Open app permission settings") }

        Section("Permissions used")
        Note("Microphone (voice input) and network state (to show offline errors). Calls and texts are only prepared in your dialer/messages app — you press call or send yourself — so no call or SMS permission is needed. Contacts access is not requested.")
    }
}

private fun hasMic(c: Context) =
    ContextCompat.checkSelfPermission(c, Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED

private fun openTtsSettings(c: Context) {
    val intents = listOf(Intent("com.android.settings.TTS_SETTINGS"), Intent(AndroidSettings.ACTION_SETTINGS))
    for (i in intents) { try { c.startActivity(i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)); return } catch (_: Exception) {} }
}

@Composable private fun Section(t: String) =
    Text(t, color = JarvisCyan, fontSize = 15.sp, fontWeight = FontWeight.SemiBold, modifier = Modifier.padding(top = 16.dp))

@Composable private fun Note(t: String) = Text(t, color = JarvisMuted, fontSize = 12.sp)
