package com.jarvis.ai.ui

import android.Manifest
import android.content.pm.PackageManager
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.core.*
import androidx.compose.foundation.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.rounded.Send
import androidx.compose.material.icons.rounded.Mic
import androidx.compose.material.icons.rounded.Settings
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.semantics.Role as SemRole
import androidx.compose.ui.text.font.FontStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.ContextCompat
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.jarvis.ai.*

@Composable
fun JarvisScreen(vm: JarvisViewModel, onOpenSettings: () -> Unit) {
    val messages by vm.messages.collectAsStateWithLifecycle()
    val state by vm.state.collectAsStateWithLifecycle()
    val partial by vm.partialText.collectAsStateWithLifecycle()
    val level by vm.micLevel.collectAsStateWithLifecycle()
    val pending by vm.pending.collectAsStateWithLifecycle()
    val context = LocalContext.current
    var showRationale by remember { mutableStateOf(false) }
    var input by rememberSaveable { mutableStateOf("") }
    val listState = rememberLazyListState()

    val permLauncher = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { ok ->
        if (ok) vm.onMicTapped() else vm.onPermissionDenied()
    }
    fun onMic() {
        val granted = ContextCompat.checkSelfPermission(context, Manifest.permission.RECORD_AUDIO) ==
            PackageManager.PERMISSION_GRANTED
        if (granted || state != JarvisState.IDLE) vm.onMicTapped() else showRationale = true
    }
    fun send() { if (input.isNotBlank()) { vm.submitText(input); input = "" } }

    LaunchedEffect(messages.size) { if (messages.isNotEmpty()) listState.animateScrollToItem(messages.lastIndex) }

    Box(Modifier.fillMaxSize().background(Brush.verticalGradient(listOf(JarvisBgTop, JarvisBg)))) {
        Column(Modifier.fillMaxSize().statusBarsPadding().navigationBarsPadding().imePadding()) {
            Row(Modifier.fillMaxWidth().padding(start = 20.dp, end = 8.dp, top = 8.dp), verticalAlignment = Alignment.CenterVertically) {
                Column(Modifier.weight(1f)) {
                    Text("JARVIS AI", color = JarvisCyan, fontSize = 22.sp, fontWeight = FontWeight.Bold, letterSpacing = 4.sp)
                    Text(statusLabel(state), color = JarvisMuted, fontSize = 12.sp)
                }
                IconButton(onClick = onOpenSettings) {
                    Icon(Icons.Rounded.Settings, contentDescription = "Settings", tint = JarvisText)
                }
            }

            LazyColumn(
                Modifier.weight(1f).fillMaxWidth(),
                state = listState,
                contentPadding = PaddingValues(horizontal = 16.dp, vertical = 8.dp),
                verticalArrangement = Arrangement.spacedBy(10.dp),
            ) { items(messages, key = { it.id }) { MessageBubble(it) } }

            pending?.let { p ->
                Column(
                    Modifier.padding(horizontal = 16.dp).fillMaxWidth().clip(RoundedCornerShape(16.dp))
                        .background(Color(0xFF0C2240)).border(1.dp, JarvisCyan.copy(alpha = .6f), RoundedCornerShape(16.dp))
                        .padding(14.dp)
                ) {
                    Text(p.prompt, color = JarvisText, fontSize = 14.sp)
                    Row(Modifier.align(Alignment.End).padding(top = 8.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        TextButton(onClick = vm::cancelPending) { Text("Cancel") }
                        Button(onClick = vm::confirmPending) { Text("Confirm") }
                    }
                }
            }

            if (partial.isNotBlank()) {
                Text(partial, color = JarvisMuted, fontStyle = FontStyle.Italic, textAlign = TextAlign.Center,
                    modifier = Modifier.fillMaxWidth().padding(horizontal = 24.dp, vertical = 4.dp))
            }

            Box(Modifier.fillMaxWidth(), contentAlignment = Alignment.Center) {
                GlowingMic(state, level, ::onMic)
            }

            Row(Modifier.fillMaxWidth().padding(horizontal = 12.dp, vertical = 8.dp), verticalAlignment = Alignment.CenterVertically) {
                OutlinedTextField(
                    value = input, onValueChange = { input = it },
                    modifier = Modifier.weight(1f),
                    placeholder = { Text("Type a command…", color = JarvisMuted) },
                    shape = RoundedCornerShape(24.dp), maxLines = 3,
                    keyboardOptions = KeyboardOptions(imeAction = ImeAction.Send),
                    keyboardActions = KeyboardActions(onSend = { send() }),
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedBorderColor = JarvisCyan, unfocusedBorderColor = JarvisBlue.copy(alpha = .5f),
                        focusedTextColor = JarvisText, unfocusedTextColor = JarvisText, cursorColor = JarvisCyan),
                )
                IconButton(onClick = ::send, enabled = input.isNotBlank()) {
                    Icon(Icons.AutoMirrored.Rounded.Send, contentDescription = "Send",
                        tint = if (input.isNotBlank()) JarvisCyan else JarvisMuted)
                }
            }
        }
    }

    if (showRationale) {
        AlertDialog(
            onDismissRequest = { showRationale = false },
            title = { Text("Microphone access") },
            text = { Text("JARVIS listens only after you tap the mic button, and stops when you finish speaking. Audio is handled by Android's speech recognition service and is never recorded in the background.") },
            confirmButton = { TextButton(onClick = { showRationale = false; permLauncher.launch(Manifest.permission.RECORD_AUDIO) }) { Text("Continue") } },
            dismissButton = { TextButton(onClick = { showRationale = false }) { Text("Not now") } },
        )
    }
}

private fun statusLabel(s: JarvisState) = when (s) {
    JarvisState.IDLE -> "Tap the mic to speak"
    JarvisState.LISTENING -> "Listening…"
    JarvisState.THINKING -> "Thinking…"
    JarvisState.SPEAKING -> "Speaking — tap to stop"
}

@Composable
private fun MessageBubble(m: ChatMessage) {
    val isUser = m.role == Role.USER
    val shape = RoundedCornerShape(18.dp, 18.dp, if (isUser) 4.dp else 18.dp, if (isUser) 18.dp else 4.dp)
    val (bg, border) = when (m.role) {
        Role.USER -> Color(0xFF0D4A94) to JarvisBlue
        Role.JARVIS -> Color(0xFF0A1B33) to JarvisCyan.copy(alpha = .4f)
        Role.ERROR -> Color(0xFF2B1218) to Color(0xFFFF6B6B).copy(alpha = .7f)
    }
    Row(Modifier.fillMaxWidth(), horizontalArrangement = if (isUser) Arrangement.End else Arrangement.Start) {
        Text(m.text, color = JarvisText, fontSize = 15.sp,
            modifier = Modifier.widthIn(max = 300.dp).clip(shape).background(bg)
                .border(1.dp, border, shape).padding(horizontal = 14.dp, vertical = 10.dp))
    }
}

@Composable
private fun GlowingMic(state: JarvisState, level: Float, onClick: () -> Unit) {
    val transition = rememberInfiniteTransition(label = "pulse")
    val pulse by transition.animateFloat(0f, 1f, infiniteRepeatable(tween(2200, easing = LinearEasing)), label = "p")
    val lvl by animateFloatAsState(level, label = "lvl")
    val active = state != JarvisState.IDLE
    val core = if (state == JarvisState.LISTENING) JarvisCyan else JarvisBlue

    Box(Modifier.size(210.dp), contentAlignment = Alignment.Center) {
        Canvas(Modifier.fillMaxSize()) {
            val r = 56.dp.toPx()
            drawCircle(
                Brush.radialGradient(listOf(core.copy(alpha = .30f + .35f * lvl), Color.Transparent), radius = size.minDimension / 2),
                radius = size.minDimension / 2,
            )
            if (active) repeat(2) { i ->
                val p = (pulse + i * .5f) % 1f
                drawCircle(JarvisCyan.copy(alpha = (1f - p) * .5f), radius = r * (1.1f + p * .8f), style = Stroke(2.dp.toPx()))
            }
            drawCircle(JarvisCyan.copy(alpha = .55f), radius = r * 1.15f + lvl * 14.dp.toPx(), style = Stroke(1.5.dp.toPx()))
        }
        Box(
            Modifier.size(112.dp).clip(CircleShape)
                .background(Brush.radialGradient(listOf(core.copy(alpha = .9f), Color(0xFF06223F))))
                .border(2.dp, JarvisCyan, CircleShape)
                .clickable(role = SemRole.Button, onClickLabel = "Microphone", onClick = onClick),
            contentAlignment = Alignment.Center,
        ) {
            Icon(Icons.Rounded.Mic, contentDescription = statusLabel(state), tint = Color.White, modifier = Modifier.size(48.dp))
        }
    }
}
