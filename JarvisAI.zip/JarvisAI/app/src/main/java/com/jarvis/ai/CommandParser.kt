package com.jarvis.ai

import java.util.Locale

sealed interface Command {
    data class OpenApp(val name: String) : Command
    data object AskTime : Command
    data class Call(val number: String?) : Command
    data class Sms(val number: String?, val body: String?) : Command
    /** Writing help / translation / open questions: needs an external AI service. */
    data class AskAi(val prompt: String) : Command
    data object Empty : Command
    data class Unknown(val text: String) : Command
}

/** Rule-based English + Hausa command understanding. */
object CommandParser {
    private val wake = Regex("^(hey\\s+|hi\\s+|ya\\s+)?jarvis[,.!?\\s]*", RegexOption.IGNORE_CASE)
    private val open = Regex("^(?:please\\s+)?(?:open|launch|start|run|buɗe|bude|buda|kunna)\\s+(.+)$")
    private val number = Regex("\\+?\\d[\\d\\s\\-]{5,}\\d")
    private val body = Regex("(?:saying|says|that says|cewa|with message)\\s+(.+)$")
    private val timeWords = listOf("what time", "time is it", "current time", "the time", "karfe nawa", "lokaci")
    private val aiWords = listOf("write", "draft", "compose", "translate", "fassara", "rubuta", "help me")
    private val callStart = listOf("call ", "phone ", "dial ", "kira ", "buga ")
    private val smsWords = listOf("text ", "sms", "message", "saƙo", "sako", "aika")

    fun parse(raw: String): Command {
        val text = raw.trim().replace(wake, "").trim().trimEnd('.', '!', '?', ',')
        val lower = text.lowercase(Locale.ROOT)
        if (lower.isEmpty()) return Command.Empty

        open.matchEntire(lower)?.let { m ->
            val name = m.groupValues[1]
                .replace(Regex("^(the|min|mini)\\s+"), "")
                .replace(Regex("\\s+(app|application|manhaja)$"), "").trim()
            if (name.isNotEmpty()) return Command.OpenApp(name)
        }
        if (timeWords.any { it in lower }) return Command.AskTime
        if (aiWords.any { it in lower }) return Command.AskAi(text)

        val num = number.find(text)?.value?.filter { it.isDigit() || it == '+' }
        if (callStart.any { lower.startsWith(it) } || lower == "call") return Command.Call(num)
        if (smsWords.any { it in lower }) {
            return Command.Sms(num, body.find(text)?.groupValues?.get(1)?.trim())
        }
        return Command.Unknown(text)
    }
}
