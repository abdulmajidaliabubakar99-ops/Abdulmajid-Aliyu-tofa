package com.jarvis.ai

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.viewModels
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import com.jarvis.ai.ui.JarvisScreen
import com.jarvis.ai.ui.JarvisTheme
import com.jarvis.ai.ui.SettingsScreen

class MainActivity : ComponentActivity() {
    private val vm: JarvisViewModel by viewModels()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            JarvisTheme {
                var showSettings by rememberSaveable { mutableStateOf(false) }
                BackHandler(showSettings) { showSettings = false }
                if (showSettings) SettingsScreen(vm) { showSettings = false }
                else JarvisScreen(vm) { showSettings = true }
            }
        }
    }
}
