package com.jarvis.ai

import android.Manifest
import android.app.Application
import android.content.ActivityNotFoundException
import android.content.Intent
import android.content.pm.PackageManager
import android.net.ConnectivityManager
import android.net.NetworkCapabilities
import android.net.Uri
import androidx.core.content.ContextCompat
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch
import java.time.LocalTime
import java.time.format.DateTimeFormatter
import java.time.format.FormatStyle

enum class JarvisState { IDLE, LISTENING, THINKING, SPEAKING }
enum class Role { USER, JARVIS, ERROR }
data class ChatMessage(val id: Long, val role: Role, val text: String)

sealed interface PendingAction {
    val prompt: String
    data class Dial(val number: String, override val prompt: String) : PendingAction
    data class Sms(val number: String, val body: String?, override val prompt: String) : PendingAction
}

class JarvisViewModel(app: Application) : AndroidViewModel(app) {
    private val ctx = app.applicationContext
    private val settingsRepo = SettingsRepository(ctx)
    val settings: StateFlow<Settings> = settingsRepo.settings

    private val launcher = AppLauncher(ctx)
    private val brain: AssistantBrain = NotConfiguredBrain()

    private var nextId = 0L
    private var ttsNoticeShown = false

    private val _messages = MutableStateFlow<List<ChatMessage>>(emptyList())
    val messages = _messages.asStateFlow()
    private val _state = MutableStateFlow(JarvisState.IDLE)
    val state = _state.asStateFlow()
    private val _partial = MutableStateFlow("")
    val partialText = _partial.asStateFlow()
    private val _level = MutableStateFlow(0f)
    val micLevel = _level.asStateFlow()
    private val _pending = MutableStateFlow<PendingAction?>(null)
    val pending = _pending.asStateFlow()

    private val tts = TtsController(ctx) { if (_state.value == JarvisState.SPEAKING) _state.value = JarvisState.IDLE }

    private val speech = SpeechController(ctx, object : SpeechController.Listener {
        override fun onPartial(text: String) { _partial.value = text }
        override fun onLevel(level: Float) { _level.value = level }
        override fun onResult(text: String) { _partial.value = ""; _level.value = 0f; handle(text) }
        override fun onError(message: String) {
            _partial.value = ""; _level.value = 0f
            _state.value = JarvisState.IDLE
            add(Role.ERROR, message)
        }
    })

    init { add(Role.JARVIS, t("Hello, I'm JARVIS. Tap the mic or type a command.",
        "Sannu, ni ce JARVIS. Danna makirufo ko rubuta umarni.")) }

    private fun t(en: String, ha: String) = if (settings.value.language.isHausa) ha else en

    private fun add(role: Role, text: String) {
        _messages.value = _messages.value + ChatMessage(nextId++, role, text)
    }

    // ---- Settings ----
    fun setLanguage(l: AppLanguage) = settingsRepo.update { it.copy(language = l) }
    fun setVoiceOutput(on: Boolean) {
        settingsRepo.update { it.copy(voiceOutput = on) }
        if (!on) { tts.stop(); if (_state.value == JarvisState.SPEAKING) _state.value = JarvisState.IDLE }
    }
    fun setSpeechRate(r: Float) = settingsRepo.update { it.copy(speechRate = r) }

    // ---- Mic ----
    fun onMicTapped() {
        when (_state.value) {
            JarvisState.IDLE -> startListening()
            JarvisState.LISTENING -> speech.stopListening()
            JarvisState.SPEAKING -> { tts.stop(); _state.value = JarvisState.IDLE }
            JarvisState.THINKING -> Unit
        }
    }

    fun onPermissionDenied() = add(Role.ERROR,
        "Microphone permission was denied, so I can't listen. You can type commands, or enable the microphone in Settings.")

    private fun startListening() {
        val granted = ContextCompat.checkSelfPermission(ctx, Manifest.permission.RECORD_AUDIO) ==
            PackageManager.PERMISSION_GRANTED
        if (!granted) { onPermissionDenied(); return }
        if (!speech.isAvailable()) {
            add(Role.ERROR, "Speech recognition isn't available on this device. Install or enable a speech service (e.g. the Google app), or type instead.")
            return
        }
        tts.stop()
        _state.value = JarvisState.LISTENING
        speech.start(settings.value.language.tag)
    }

    fun submitText(text: String) = handle(text)

    // ---- Command handling ----
    private val yes = setOf("yes", "yeah", "yep", "confirm", "ok", "okay", "go ahead", "do it", "ee", "eh", "tabbas")
    private val no = setOf("no", "nope", "cancel", "stop", "a'a", "aa", "soke")

    private fun handle(raw: String) {
        val text = raw.trim()
        if (text.isEmpty()) { _state.value = JarvisState.IDLE; return }
        add(Role.USER, text)
        val answer = text.lowercase().replace(Regex("^jarvis[,\\s]*"), "").trim('.', '!', ' ')
        if (_pending.value != null) {
            if (answer in yes) { confirmPending(); return }
            if (answer in no) { cancelPending(); return }
            _pending.value = null
        }
        _state.value = JarvisState.THINKING
        when (val cmd = CommandParser.parse(text)) {
            Command.Empty -> say(t("Yes? Try \"open YouTube\" or \"what time is it\".", "Na'am? Gwada \"buɗe YouTube\" ko \"karfe nawa ne\"."))
            is Command.OpenApp -> openApp(cmd.name)
            Command.AskTime -> {
                val now = LocalTime.now().format(DateTimeFormatter.ofLocalizedTime(FormatStyle.SHORT))
                say(t("It's $now.", "Yanzu karfe $now ne."))
            }
            is Command.Call -> {
                if (cmd.number == null) say(t(
                    "Who should I call? Say or type the phone number. (I can't read your contacts yet.)",
                    "Wa zan kira? Faɗi ko rubuta lambar waya. (Har yanzu ba zan iya karanta lambobin wayarka ba.)"))
                else ask(PendingAction.Dial(cmd.number, t(
                    "Open the dialer for ${cmd.number}? Nothing is dialed until you press the call button.",
                    "Zan buɗe wurin kira don ${cmd.number}? Ba za a kira ba sai ka danna maɓallin kira.")))
            }
            is Command.Sms -> {
                if (cmd.number == null) say(t(
                    "Which number should I text? Say or type it, e.g. \"text 0803 123 4567 saying I'm on my way\".",
                    "Zuwa wace lamba? Faɗi ko rubuta ta, misali \"aika sako 0803 123 4567 cewa ina hanya\"."))
                else ask(PendingAction.Sms(cmd.number, cmd.body, t(
                    "Prepare a text to ${cmd.number}${cmd.body?.let { " saying \"$it\"" } ?: ""}? You'll review it and press send yourself.",
                    "Zan shirya saƙo zuwa ${cmd.number}? Za ka duba shi ka aika da kanka.")))
            }
            is Command.AskAi -> askAi(cmd.prompt)
            is Command.Unknown -> say(t(
                "I'm not sure how to do that. I can open apps, tell the time, and prepare calls or texts. Free conversation needs an AI service, which isn't set up yet.",
                "Ban gane ba. Zan iya buɗe manhajoji, in faɗi lokaci, in shirya kira ko saƙo. Tattaunawa ta yau da kullum tana buƙatar sabis na AI, wanda ba a saita ba tukuna."))
        }
    }

    private fun openApp(name: String) {
        val app = launcher.find(name)
        if (app == null) {
            say(t("I couldn't find an app called \"$name\" on this phone.", "Ban sami manhajar \"$name\" a wannan wayar ba."), true)
        } else if (launcher.launch(app)) {
            say(t("Opening ${app.label}.", "Ina buɗe ${app.label}."))
        } else {
            say(t("I found ${app.label} but couldn't open it.", "Na sami ${app.label} amma ban iya buɗe ta ba."), true)
        }
    }

    private fun askAi(prompt: String) {
        if (!brain.isConfigured) {
            say(t("Writing help and translation need an AI service, which isn't configured yet. See the README to connect one.",
                "Taimakon rubutu da fassara suna buƙatar sabis na AI, wanda ba a saita ba tukuna. Duba README."), true)
            return
        }
        if (!isOnline()) {
            say(t("No internet connection. Please check your connection and try again.",
                "Babu intanet. Duba haɗinka ka sake gwadawa."), true)
            return
        }
        viewModelScope.launch {
            brain.respond(prompt, settings.value.language.tag)
                .onSuccess { say(it) }
                .onFailure { say("The AI request failed: ${it.message}", true) }
        }
    }

    private fun ask(action: PendingAction) {
        _pending.value = action
        say(action.prompt + " " + t("Say \"yes\" or tap Confirm.", "Ka ce \"ee\" ko ka danna Tabbatar."))
    }

    fun confirmPending() {
        val p = _pending.value ?: return
        _pending.value = null
        val intent = when (p) {
            is PendingAction.Dial -> Intent(Intent.ACTION_DIAL, Uri.fromParts("tel", p.number, null))
            is PendingAction.Sms -> Intent(Intent.ACTION_SENDTO, Uri.fromParts("smsto", p.number, null))
                .putExtra("sms_body", p.body ?: "")
        }.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        try {
            ctx.startActivity(intent)
            say(if (p is PendingAction.Dial)
                t("Dialer opened. Press the call button when you're ready.", "An buɗe wurin kira. Danna maɓallin kira idan ka shirya.")
            else t("Message is ready. Review it and press send.", "Saƙon ya shirya. Duba shi ka danna aika."))
        } catch (_: ActivityNotFoundException) {
            say(t("No app on this phone can handle that.", "Babu manhajar da za ta iya yin hakan a wannan wayar."), true)
        }
    }

    fun cancelPending() {
        _pending.value = null
        say(t("Okay, cancelled.", "To, an fasa."))
    }

    // ---- Output ----
    private fun say(text: String, isError: Boolean = false) {
        add(if (isError) Role.ERROR else Role.JARVIS, text)
        val s = settings.value
        if (!s.voiceOutput) { _state.value = JarvisState.IDLE; return }
        when (tts.speak(text, s.language.locale, s.speechRate)) {
            SpeakResult.OK -> _state.value = JarvisState.SPEAKING
            SpeakResult.LANGUAGE_FALLBACK -> {
                _state.value = JarvisState.SPEAKING
                if (!ttsNoticeShown) {
                    ttsNoticeShown = true
                    add(Role.ERROR, "A ${s.language.label} voice isn't installed, so I'm using English speech. Install one in Settings → Voice output.")
                }
            }
            SpeakResult.UNAVAILABLE -> {
                _state.value = JarvisState.IDLE
                if (!ttsNoticeShown) {
                    ttsNoticeShown = true
                    add(Role.ERROR, "Text-to-speech isn't available on this device, so I'll reply in text only.")
                }
            }
        }
    }

    private fun isOnline(): Boolean {
        val cm = ctx.getSystemService(ConnectivityManager::class.java) ?: return false
        val caps = cm.getNetworkCapabilities(cm.activeNetwork) ?: return false
        return caps.hasCapability(NetworkCapabilities.NET_CAPABILITY_INTERNET)
    }

    override fun onCleared() {
        speech.destroy()
        tts.shutdown()
    }
}
