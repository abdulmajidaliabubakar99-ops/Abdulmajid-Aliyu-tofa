package com.jarvis.ai

import android.content.ActivityNotFoundException
import android.content.Context
import android.content.Intent
import java.util.Locale

/** Finds and launches installed apps via PackageManager launch intents (no special permission). */
class AppLauncher(private val context: Context) {
    data class AppInfo(val label: String, val packageName: String)

    @Suppress("DEPRECATION")
    fun installedApps(): List<AppInfo> {
        val pm = context.packageManager
        val intent = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
        return pm.queryIntentActivities(intent, 0)
            .map { AppInfo(it.loadLabel(pm).toString(), it.activityInfo.packageName) }
            .distinctBy { it.packageName }
    }

    private fun norm(s: String) = s.lowercase(Locale.ROOT).filter { it.isLetterOrDigit() }

    fun find(query: String): AppInfo? {
        val q = norm(query)
        if (q.isEmpty()) return null
        val apps = installedApps().map { it to norm(it.label) }
        return apps.firstOrNull { it.second == q }?.first
            ?: apps.firstOrNull { it.second.startsWith(q) }?.first
            ?: apps.firstOrNull { it.second.contains(q) }?.first
            ?: apps.firstOrNull { it.second.length >= 3 && q.contains(it.second) }?.first
    }

    fun launch(app: AppInfo): Boolean {
        val intent = context.packageManager.getLaunchIntentForPackage(app.packageName) ?: return false
        intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        return try { context.startActivity(intent); true } catch (_: ActivityNotFoundException) { false }
    }
}
