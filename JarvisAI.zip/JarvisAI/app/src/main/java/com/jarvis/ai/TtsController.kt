package com.jarvis.ai

import android.content.Context
import android.os.Handler
import android.os.Looper
import android.speech.tts.TextToSpeech
import android.speech.tts.UtteranceProgressListener
import java.util.Locale

enum class SpeakResult { OK, LANGUAGE_FALLBACK, UNAVAILABLE }

class TtsController(context: Context, private val onDone: () -> Unit) {
    private class Request(val text: String, val locale: Locale, val rate: Float)

    private val main = Handler(Looper.getMainLooper())
    private var ready = false
    private var failed = false
    private var queued: Request? = null
    private var tts: TextToSpeech? = null

    init {
        tts = TextToSpeech(context.applicationContext) { status ->
            if (status == TextToSpeech.SUCCESS) {
                ready = true
                tts?.setOnUtteranceProgressListener(object : UtteranceProgressListener() {
                    override fun onStart(utteranceId: String?) {}
                    override fun onDone(utteranceId: String?) { main.post(onDone) }
                    @Deprecated("Deprecated in Java")
                    override fun onError(utteranceId: String?) { main.post(onDone) }
                })
                queued?.let { speak(it.text, it.locale, it.rate) }
                queued = null
            } else {
                failed = true
                main.post(onDone)
            }
        }
    }

    fun speak(text: String, locale: Locale, rate: Float): SpeakResult {
        if (failed) return SpeakResult.UNAVAILABLE
        val engine = tts
        if (!ready || engine == null) { queued = Request(text, locale, rate); return SpeakResult.OK }
        var result = SpeakResult.OK
        val lang = engine.setLanguage(locale)
        if (lang == TextToSpeech.LANG_MISSING_DATA || lang == TextToSpeech.LANG_NOT_SUPPORTED) {
            engine.setLanguage(Locale.US)
            result = SpeakResult.LANGUAGE_FALLBACK
        }
        engine.setSpeechRate(rate)
        val r = engine.speak(text, TextToSpeech.QUEUE_FLUSH, null, "jarvis-${System.nanoTime()}")
        return if (r == TextToSpeech.ERROR) SpeakResult.UNAVAILABLE else result
    }

    fun stop() { tts?.stop() }

    fun shutdown() { tts?.stop(); tts?.shutdown(); tts = null }
}
