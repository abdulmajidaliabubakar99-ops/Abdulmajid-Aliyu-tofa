# JARVIS AI (Kotlin + Jetpack Compose)

Open this folder in Android Studio (Ladybug or newer) and run. If the Gradle wrapper jar is missing, Android Studio will offer to sync with Gradle 8.9 (or run `gradle wrapper`).

## Working now
- Glowing mic button, live conversation, typed input
- Speech input (Android SpeechRecognizer) and spoken replies (TextToSpeech), English + Hausa
- "Jarvis, open <any installed app>" (e.g. YouTube, WhatsApp), "what time is it"
- Call / text preparation: opens the dialer or SMS composer after in-app confirmation; you press call/send
- Settings: language, voice on/off, speed, microphone permission

## Needs extra setup / not implemented
- "Help me write a message", "translate this": need an external AI API. Implement `AssistantBrain`, add `INTERNET` permission, return it in `JarvisViewModel`.
- Contact-name lookup: needs READ_CONTACTS (not requested yet). Numbers must be spoken/typed.
- Hausa speech recognition/voice depend on the device's speech services.
- No always-on "Hey Jarvis" wake word (by design: no background listening).
- Hausa reply strings should be reviewed by a native speaker.
